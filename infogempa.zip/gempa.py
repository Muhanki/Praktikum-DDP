class gempa:
    def __init__(self, lokasi, skala ):
        self.lokasi = lokasi
        self.skala = skala

    def dampak(self):
        if self.skala < 2.0:
            level_dampak = "Tidak terasa"
        elif 2.0 <=self.skala < 4.0:
            level_dampak = "Ringan, sedikit terasa"
        elif 4.0 <=self.skala < 6.0:
            level_dampak = "Sedang, terasa cukup kuat"
        elif 6.0 <=self.skala < 7.5:
            level_dampak = "Kuat, dapat merusak bangunan"
        else:
            level_dampak = "Sangat kuat, potensi bencana besar"

        print(f"Lokasi: {self.lokasi}, skala: {self.skala}, Dampak: {level_dampak}")

# Membuat objek gempa
gempa1 = gempa('Banten', 1.2)
gempa2 = gempa('Palu', 6.1)
gempa3 = gempa('Cianjur', 5.6)
gempa4 = gempa('Jayapura', 7.3)
gempa5 = gempa('Garut', 5.5)

# Informasi gempa
print(' ##  Info Gempa Mazzeh  ## ')
gempa1.dampak()
print(' ##  Info Gempa Mazzeh  ## ')
gempa2.dampak()
print(' ##  Info Gempa Mazzeh  ## ')
gempa3.dampak()
print(' ##  Info Gempa Mazzeh  ## ')
gempa4.dampak()
print(' ##  Info Gempa Mazzeh  ## ')
gempa5.dampak()
