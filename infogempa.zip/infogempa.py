# memanggil file gempa dan import semua method dan fungsi
from gempa import *


# membuat objek gempa
gempa1 = gempa('Banten', 1.2) 
gempa2 = gempa('palu', 6.1) 
gempa3 = gempa('cianjur', 5.6) 
gempa4 = gempa('jayapura', 7.3) 
gempa5 = gempa('garut', 5.5) 

# informasi
# Informasi gempa
print(' ##  Info Gempa Mazzeh  ## ')
gempa1.dampak()
print()  

print(' ##  Info Gempa Mazzeh  ## ')
gempa2.dampak()
print()  

print(' ##  Info Gempa Mazzeh  ## ')
gempa3.dampak()
print()  

print(' ##  Info Gempa Mazzeh  ## ')
gempa4.dampak()
print()  

print(' ##  Info Gempa Mazzeh  ## ')
gempa5.dampak()
print()  
