#penjumlahan
angka1 = 15
angka2 = 5

hasil = angka1 + angka2
print(f"Hasil tambah {angka1} + {angka2} adalah {hasil}")

#pengurangan
angka1 = 15
angka2 = 5

hasil = angka1 - angka2
print(f"Hasil pengurangan {angka1} - {angka2} adalah {hasil}")

#pembagian
angka1 = 20
angka2 = 4

hasil = angka1 / angka2
print(f"Hasil pembagian {angka1} / {angka2} adalah {hasil}")

#perkalian
angka1 = 20
angka2 = 4

hasil = angka1 * angka2
print(f"Hasil pembagian {angka1} * {angka2} adalah {hasil}")

#pangkat
angka = 3
pangkat = 4

hasil = angka ** pangkat
print(f"Hasil {angka} pangkat {pangkat} adalah {hasil}")