import datar as im

im.hitung_persegi 
im.hitung_segitiga
im.hitung_lingkaran
im.hitung_luas_persegi_panjang
im.hitung_luas_jajar_genjang

import bangunruang as barung

barung.hitung_luas_permukaan_kubus
barung.hitung_luas_permukaan_balok
barung.hitung_luas_permukaan_tabung
barung.hitung_luas_permukaan_limas
barung.hitung_luas_permukaan_prisma

import tambah as kalkulator


